package com.mcwabane.enviro365;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Enviro365ApplicationTests {

	@Test
	void contextLoads() {
	}

}
