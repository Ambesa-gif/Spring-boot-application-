package com.mcwabane.enviro365.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.mcwabane.enviro365.model.TipModel;
import com.mcwabane.enviro365.repository.TipRepo;

@RestController
public class TipController {
    @Autowired
    private TipRepo tipRepo;

    @GetMapping("tip")
    public List<TipModel> logTip(){
        return tipRepo.findAll();
    }
    
    @GetMapping("tip/get/{id}")
    public Optional<TipModel> getTipModel(@PathVariable Long id){
        return tipRepo.findById(id);

    }

    @PostMapping("tip/add")
    public TipModel addTipName(@RequestBody TipModel tip){
        return tipRepo.saveAndFlush(tip);
    }

    @DeleteMapping("tip/delete/{id}")
    public void deleteTipModel(@PathVariable Long id){
        tipRepo.deleteById(id);
    }
}
