package com.mcwabane.enviro365.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "ITEM")
public class ItemModel {
    @Id
    private Long id;
    
    private String name;
    private String description;
    private String disposal;

    public ItemModel(){}

    public ItemModel(Long id, String name, String description, String disposal) {
        this.id = id;
        this.name = name;
        this.description = description;
        this.disposal = disposal;
    }


    public Long getID() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    public String getDisposal() {
        return disposal;
    }

}

