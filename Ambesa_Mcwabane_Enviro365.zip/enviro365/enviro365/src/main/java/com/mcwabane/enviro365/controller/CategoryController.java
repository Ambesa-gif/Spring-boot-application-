package com.mcwabane.enviro365.controller;


import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.mcwabane.enviro365.model.WasteCategoryModel;
import com.mcwabane.enviro365.repository.CategoryRepo;


@RestController
public class CategoryController{
    @Autowired
    private CategoryRepo categoryRepo;

    @GetMapping("category")
    public List<WasteCategoryModel> logCategory(){
        return categoryRepo.findAll();
    }

    @GetMapping("category/{id}")
    public Optional<WasteCategoryModel> getCategoryModel(@PathVariable Long id){
        return categoryRepo.findById(id);
    }

    @PostMapping("category/add")
    public  WasteCategoryModel addCategoryName(@RequestBody WasteCategoryModel category){
        return categoryRepo.saveAndFlush(category); 
    }

    @DeleteMapping("category/delete/{id}")
    public void deleteCategoryName(@PathVariable Long id){
        categoryRepo.deleteById(id);
    }

}
