package com.mcwabane.enviro365.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.mcwabane.enviro365.model.TipModel;

@Repository
public interface TipRepo extends JpaRepository<TipModel, Long>{

    
}
