package com.mcwabane.enviro365.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "TIP")
public class TipModel {
    @Id
    private Long id;
    
    private String category;
    private String text; 


    public TipModel(){}

    public TipModel(Long id, String category, String text){
        this.id = id;
        this.category = category;
        this.text = text;
    }

    public Long getID() {
        return id;
    }

    public String getCategory() {
        return category;
    }

    public String getText() {
        return text;
    }
}
