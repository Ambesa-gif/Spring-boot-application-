package com.mcwabane.enviro365.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.mcwabane.enviro365.model.ItemModel;
import com.mcwabane.enviro365.repository.ItemRepo;
import java.util.List;
import java.util.Optional;
@RestController
public class ItemController {
    @Autowired
    private ItemRepo itemRepo;

    @GetMapping("item")
    public List<ItemModel> logItem(){
        return itemRepo.findAll();
    }

    @GetMapping("item/{id}")
    public Optional<ItemModel> getItemModel(@PathVariable Long id){
        return itemRepo.findById(id);
    }

    @PostMapping("item/add")
    public ItemModel addItemName(@RequestBody ItemModel item){
        return itemRepo.saveAndFlush(item); 
    }

    @DeleteMapping("item/delete/{id}")
    public void deleteItemModel(@PathVariable Long id){
        itemRepo.deleteById(id);
    }


}
