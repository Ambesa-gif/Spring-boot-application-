package com.mcwabane.enviro365.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.mcwabane.enviro365.model.WasteCategoryModel;

@Repository
public interface CategoryRepo extends JpaRepository<WasteCategoryModel, Long>{
    
}
